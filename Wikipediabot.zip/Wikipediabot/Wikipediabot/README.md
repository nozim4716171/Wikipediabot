# Wikipediabot
Ushbu bot Wikipediadan ma'lumotlarni qidirib  beradigan bot. Siz ushbu botni 3 tilda foydalanishingiz mumkin. O'zbek tili, Rus tili va Ingliz tilida.

Этот бот — который ищет информацию в Википедии. Вы можете использовать этого бота на 3 языках. На узбекском, русском и английском языках.

This bot is that searches for information on Wikipedia. You can use this bot in 3 languages. In Uzbek, Russian and English.
