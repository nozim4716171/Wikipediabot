from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup


# Tilni tanlashdagi inline tugmalar
uzbutton=InlineKeyboardButton("O'zbek tili🇺🇿", callback_data="uz")
rubutton=InlineKeyboardButton("Русский язык🇷🇺", callback_data="ru")
engbutton=InlineKeyboardButton("English🇺🇸", callback_data="eng")

result=InlineKeyboardMarkup(row_width=1).row(uzbutton,rubutton).add(engbutton)