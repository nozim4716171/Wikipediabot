from aiogram import Bot, Dispatcher, executor, types
from config import API_TOKEN
import wikipedia
from inlinekeyboard import *
import wikipedia as wk




bot=Bot(API_TOKEN)
db=Dispatcher(bot)




@db.message_handler(commands=["start"])
async def start(message: types.Message):
    await message.answer("🇺🇿Kerakli tilini tanglang:\n🇷🇺Выберите нужный язык:\n🇺🇸Choose the language:", reply_markup=result)
    
@db.message_handler()
async def uzwiki(message: types.Message):
    try:
        manba=wk.summary(message.text)
        await message.answer(manba)
    except:
        await message.answer("Bunday malumot topilmadi")
    
    return uzwiki

while True:

    @db.callback_query_handler(lambda a: a.data == "uz")
    async def language(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        fullname=callback_query.from_user.full_name
        wk.set_lang("uz")
        await bot.send_message(callback_query.from_user.id,"Assalomu aleykum {} 🤝. Siz o'zbek🇺🇿 tilini tanladingiz😊.".format(fullname))

    @db.callback_query_handler(lambda a: a.data == "ru")
    async def language(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        fullname=callback_query.from_user.full_name
        wk.set_lang("ru")
        await bot.send_message(callback_query.from_user.id,"Здравствуйте {} 🤝. Вы выбрали 🇷🇺русский😊.".format(fullname))

    @db.callback_query_handler(lambda a: a.data == "eng")
    async def language(callback_query: types.CallbackQuery):
        await bot.answer_callback_query(callback_query.id)
        fullname=callback_query.from_user.full_name
        wk.set_lang("en")
        await bot.send_message(callback_query.from_user.id,"Hello {} 🤝. You have chosen 🇺🇸English😊.".format(fullname))





    if __name__ == '__main__':
        executor.start_polling(db, skip_updates=True)